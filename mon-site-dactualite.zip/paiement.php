<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST["nom"];
    $telephone = $_POST["telephone"];

    echo "<h2>Paiement reçu !</h2>";
    echo "<p>Nom : $nom</p>";
    echo "<p>Téléphone : $telephone</p>";
    echo "<p>QR Code Wi-Fi ou lien d'accès sera ici...</p>";
} else {
    echo "Erreur de connexion au serveur.";
}
?>

